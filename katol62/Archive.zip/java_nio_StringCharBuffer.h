//
//  java_nio_StringCharBuffer.h
//  HelloResources
//
//  Created by apple on 05.06.12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "java_nio_CharBuffer.h"

@interface java_nio_StringCharBuffer : java_nio_CharBuffer

@end
